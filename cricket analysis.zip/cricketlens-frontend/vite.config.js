import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // Proxy API calls to FastAPI backend so we avoid CORS in dev
    proxy: {
      "/api":   { target: "http://localhost:8000", changeOrigin: true },
      "/health":{ target: "http://localhost:8000", changeOrigin: true },
    },
  },
});
