// Thin wrapper around the FastAPI backend.
// In dev we use Vite's proxy, so relative paths are fine.
// In production, set VITE_API_BASE in .env (e.g. https://api.example.com).
const BASE = import.meta.env.VITE_API_BASE || "";

export async function uploadVideo(file, { runCommentary = true, onProgress } = {}) {
  const url = `${BASE}/api/upload?run_commentary=${runCommentary}`;

  // Use XMLHttpRequest so we can track upload progress.
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const form = new FormData();
    form.append("file", file);

    xhr.open("POST", url);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && onProgress) onProgress(e.loaded / e.total);
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try { resolve(JSON.parse(xhr.responseText)); } catch (e) { reject(e); }
      } else {
        reject(new Error(`Upload failed: ${xhr.status} ${xhr.responseText}`));
      }
    };
    xhr.onerror = () => reject(new Error("Network error during upload"));
    xhr.send(form);
  });
}

export async function getJob(jobId) {
  const r = await fetch(`${BASE}/api/jobs/${jobId}`);
  if (!r.ok) throw new Error(`Job fetch failed: ${r.status}`);
  return r.json();
}

export async function getEvents(jobId) {
  const r = await fetch(`${BASE}/api/events/${jobId}`);
  if (!r.ok) throw new Error(`Events fetch failed: ${r.status}`);
  return r.json();
}

export async function listJobs() {
  const r = await fetch(`${BASE}/api/jobs`);
  if (!r.ok) throw new Error(`Jobs list failed: ${r.status}`);
  return r.json();
}

export async function deleteJob(jobId) {
  const r = await fetch(`${BASE}/api/jobs/${jobId}`, { method: "DELETE" });
  if (!r.ok) throw new Error(`Delete failed: ${r.status}`);
  return r.json();
}

/**
 * Subscribe to the SSE stream for a job.
 * onUpdate({ status, progress, message, events }) is called for every message.
 * Returns a cleanup function.
 */
export function streamProgress(jobId, onUpdate, onError) {
  const es = new EventSource(`${BASE}/api/stream/${jobId}`);
  es.onmessage = (e) => {
    try {
      const data = JSON.parse(e.data);
      onUpdate(data);
      if (data.status === "done" || data.status === "error") es.close();
    } catch (err) {
      onError?.(err);
    }
  };
  es.onerror = (err) => {
    onError?.(err);
    es.close();
  };
  return () => es.close();
}

/** Build the URL the <video> tag should use to stream the original upload.
 * The backend doesn't expose video streaming yet — see README in this folder.
 * For now we keep a local object-URL of the uploaded file so playback works
 * immediately after upload. */
export function buildVideoUrlFromBlob(blob) {
  return URL.createObjectURL(blob);
}
